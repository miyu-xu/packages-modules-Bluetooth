#ifndef BASE_CONTAINERS_LRU_CACHE_H_
#define BASE_CONTAINERS_LRU_CACHE_H_

#include "base/containers/mru_cache.h"

namespace base {

template <class KeyType, class PayloadType, class HashType = std::hash<KeyType>>
using HashingLRUCache = HashingMRUCache<KeyType, PayloadType, HashType>;

}

#endif  // BASE_CONTAINERS_LRU_CACHE_H_
