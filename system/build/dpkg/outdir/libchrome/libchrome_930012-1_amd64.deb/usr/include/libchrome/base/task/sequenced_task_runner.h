#ifndef BASE_TASK_SEQUENCED_TASK_RUNNER_H_
#define BASE_TASK_SEQUENCED_TASK_RUNNER_H_

#include "base/sequenced_task_runner.h"

#endif  // BASE_TASK_SEQUENCED_TASK_RUNNER_H_
