#ifndef BASE_TASK_SINGLE_THREAD_TASK_RUNNER_H_
#define BASE_TASK_SINGLE_THREAD_TASK_RUNNER_H_

#include "base/single_thread_task_runner.h"

#endif  // BASE_TASK_SINGLE_THREAD_TASK_RUNNER_H_
