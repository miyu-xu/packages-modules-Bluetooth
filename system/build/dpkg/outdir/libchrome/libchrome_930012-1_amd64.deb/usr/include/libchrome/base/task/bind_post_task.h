#ifndef BASE_TASK_BIND_POST_TASK_H_
#define BASE_TASK_BIND_POST_TASK_H_

#include "base/bind_post_task.h"

#endif  // BASE_TASK_BIND_POST_TASK_H_
